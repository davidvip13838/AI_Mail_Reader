#!/bin/bash

# Fixed Elastic Beanstalk Deployment Script
# This script ensures frontend is built and deploys correctly

set -e

echo "🚀 Elastic Beanstalk Deployment (Fixed Version)"
echo ""

# Check if frontend is built
if [ ! -d "frontend/build" ]; then
    echo "❌ Frontend build not found!"
    echo "📦 Building frontend now..."
    cd frontend
    if [ ! -d "node_modules" ]; then
        echo "Installing frontend dependencies..."
        npm install
    fi
    npm run build
    cd ..
    echo "✅ Frontend built successfully"
else
    echo "✅ Frontend build found"
fi

# Check EB environment status
echo ""
echo "📊 Checking EB environment status..."
if eb status | grep -q "Status:.*Ready"; then
    echo "✅ Environment is Ready"
else
    STATUS=$(eb status | grep "Status:" | awk '{print $2}')
    echo "⚠️  Environment status: $STATUS"
    if [ "$STATUS" != "Ready" ]; then
        echo "❌ Environment must be 'Ready' to deploy"
        echo "Wait for it to be Ready or restart via AWS Console"
        exit 1
    fi
fi

# Build deployment package
echo ""
echo "📦 Creating deployment package..."
./build-deploy.sh

# Deploy
echo ""
echo "🚀 Deploying to Elastic Beanstalk..."
echo "This may take 5-10 minutes..."
eb deploy --source deploy.zip

echo ""
echo "✅ Deployment initiated!"
echo ""
echo "Monitor progress with:"
echo "  eb events -f"
echo "  eb status"

