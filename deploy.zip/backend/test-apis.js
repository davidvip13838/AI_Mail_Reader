#!/usr/bin/env node

/**
 * Quick API Connection Test Script
 * Run this to quickly test if all APIs are configured correctly
 * Usage: node test-apis.js
 */

import dotenv from 'dotenv';
import { google } from 'googleapis';
import OpenAI from 'openai';
import axios from 'axios';

dotenv.config();

const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

function checkEnvVar(name, required = true) {
  const value = process.env[name];
  if (!value || value.includes('your_') || value.includes('_here')) {
    if (required) {
      log(`❌ ${name}: Not configured`, 'red');
      return false;
    } else {
      log(`⚠️  ${name}: Not configured (optional)`, 'yellow');
      return false;
    }
  }
  log(`✅ ${name}: Configured`, 'green');
  return true;
}

async function testGmail() {
  log('\n📧 Testing Gmail API...', 'cyan');
  
  const clientId = process.env.GOOGLE_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
  const redirectUri = process.env.GOOGLE_REDIRECT_URI;

  if (!checkEnvVar('GOOGLE_CLIENT_ID') || 
      !checkEnvVar('GOOGLE_CLIENT_SECRET') || 
      !checkEnvVar('GOOGLE_REDIRECT_URI')) {
    return false;
  }

  try {
    const oauth2Client = new google.auth.OAuth2(clientId, clientSecret, redirectUri);
    const authUrl = oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: ['https://www.googleapis.com/auth/gmail.readonly'],
      prompt: 'consent'
    });

    log(`   ✅ OAuth2 client created successfully`, 'green');
    log(`   📝 Auth URL generated: ${authUrl.substring(0, 50)}...`, 'blue');
    
    // Test with access token if available
    const accessToken = process.env.GMAIL_ACCESS_TOKEN;
    if (accessToken) {
      oauth2Client.setCredentials({ access_token: accessToken });
      const gmail = google.gmail({ version: 'v1', auth: oauth2Client });
      const profile = await gmail.users.getProfile({ userId: 'me' });
      log(`   ✅ Gmail API connected! Email: ${profile.data.emailAddress}`, 'green');
      return true;
    } else {
      log(`   ⚠️  Gmail API ready (no access token for full test)`, 'yellow');
      return true;
    }
  } catch (error) {
    log(`   ❌ Gmail API error: ${error.message}`, 'red');
    return false;
  }
}

async function testOpenAI() {
  log('\n🤖 Testing OpenAI API...', 'cyan');
  
  if (!checkEnvVar('OPENAI_API_KEY')) {
    return false;
  }

  try {
    const openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY
    });

    const completion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'user', content: 'Say "test" and nothing else.' }
      ],
      max_tokens: 10,
      temperature: 0
    });

    log(`   ✅ OpenAI API connected!`, 'green');
    log(`   📝 Response: ${completion.choices[0].message.content}`, 'blue');
    log(`   🔢 Model: ${completion.model}`, 'blue');
    return true;
  } catch (error) {
    if (error.status === 401) {
      log(`   ❌ Invalid API key`, 'red');
    } else if (error.status === 429) {
      log(`   ❌ Rate limit exceeded`, 'red');
    } else {
      log(`   ❌ OpenAI API error: ${error.message}`, 'red');
    }
    return false;
  }
}

async function testElevenLabs() {
  log('\n🎵 Testing ElevenLabs API...', 'cyan');
  
  if (!checkEnvVar('ELEVENLABS_API_KEY')) {
    return false;
  }

  try {
    const response = await axios.get('https://api.elevenlabs.io/v1/voices', {
      headers: {
        'xi-api-key': process.env.ELEVENLABS_API_KEY
      }
    });

    log(`   ✅ ElevenLabs API connected!`, 'green');
    log(`   🎤 Available voices: ${response.data.voices.length}`, 'blue');
    
    // Test TTS generation
    const ttsResponse = await axios.post(
      'https://api.elevenlabs.io/v1/text-to-speech/21m00Tcm4TlvDq8ikWAM',
      {
        text: 'Test',
        model_id: 'eleven_turbo_v2_5',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.75
        }
      },
      {
        headers: {
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': process.env.ELEVENLABS_API_KEY
        },
        responseType: 'arraybuffer'
      }
    );

    log(`   ✅ Text-to-speech working! Audio size: ${ttsResponse.data.byteLength} bytes`, 'green');
    return true;
  } catch (error) {
    // Parse error response - might be Buffer, string, or object
    let errorData = error.response?.data;
    if (Buffer.isBuffer(errorData)) {
      try {
        errorData = JSON.parse(errorData.toString());
      } catch (e) {
        errorData = { message: errorData.toString() };
      }
    }
    
    if (error.response?.status === 401) {
      const errorDetail = errorData?.detail;
      
      if (errorDetail?.status === 'missing_permissions') {
        log(`   ❌ API key missing permissions`, 'red');
        log(`   📝 Missing permission: ${errorDetail.message}`, 'yellow');
        log(`   💡 Solution:`, 'yellow');
        log(`      - Go to https://elevenlabs.io/app/settings/api-keys`, 'yellow');
        log(`      - Create a new API key or edit your existing one`, 'yellow');
        log(`      - Enable "voices_read" permission (and "text_to_speech" for TTS)`, 'yellow');
        log(`      - Update ELEVENLABS_API_KEY in your .env file`, 'yellow');
      } else if (errorDetail?.status === 'detected_unusual_activity') {
        log(`   ❌ Unusual activity detected - Free Tier disabled`, 'red');
        log(`   📝 ${errorDetail.message}`, 'yellow');
        log(`   💡 Solutions:`, 'yellow');
        log(`      - If using VPN/Proxy: Disable it or upgrade to Paid Plan`, 'yellow');
        log(`      - Upgrade to a Paid Plan at https://elevenlabs.io/pricing`, 'yellow');
        log(`      - Wait and try again later (Free Tier may be temporarily disabled)`, 'yellow');
        log(`      - Contact ElevenLabs support if you believe this is an error`, 'yellow');
      } else {
        log(`   ❌ Invalid API key`, 'red');
        log(`   📝 Response: ${JSON.stringify(errorData || {})}`, 'yellow');
        log(`   💡 Tips:`, 'yellow');
        log(`      - Check your API key at https://elevenlabs.io/app/settings/api-keys`, 'yellow');
        log(`      - Ensure the key doesn't have extra spaces or quotes`, 'yellow');
        log(`      - Make sure the key hasn't been revoked or expired`, 'yellow');
      }
    } else if (error.response?.status === 402) {
      log(`   ❌ Insufficient credits`, 'red');
    } else if (error.response?.status === 429) {
      log(`   ❌ Rate limit exceeded`, 'red');
    } else {
      log(`   ❌ ElevenLabs API error: ${errorData?.message || error.message}`, 'red');
      if (errorData) {
        log(`   📝 Full error: ${JSON.stringify(errorData)}`, 'yellow');
      }
    }
    return false;
  }
}

async function runAllTests() {
  log('\n🚀 Starting API Connection Tests...\n', 'cyan');
  log('=' .repeat(50), 'blue');

  const results = {
    gmail: await testGmail(),
    openai: await testOpenAI(),
    elevenlabs: await testElevenLabs()
  };

  log('\n' + '='.repeat(50), 'blue');
  log('\n📊 Test Results:', 'cyan');
  log(`   Gmail API:     ${results.gmail ? '✅ PASS' : '❌ FAIL'}`, results.gmail ? 'green' : 'red');
  log(`   OpenAI API:    ${results.openai ? '✅ PASS' : '❌ FAIL'}`, results.openai ? 'green' : 'red');
  log(`   ElevenLabs API: ${results.elevenlabs ? '✅ PASS' : '❌ FAIL'}`, results.elevenlabs ? 'green' : 'red');

  const allPassed = Object.values(results).every(r => r);
  
  if (allPassed) {
    log('\n🎉 All APIs are connected and working!', 'green');
    process.exit(0);
  } else {
    log('\n⚠️  Some APIs failed. Please check your .env configuration.', 'yellow');
    process.exit(1);
  }
}

runAllTests().catch(error => {
  log(`\n❌ Fatal error: ${error.message}`, 'red');
  process.exit(1);
});

